module.exports = {
    run: async (client, pendingFriend) => {
        return pendingFriend.addFriend();
    }
}